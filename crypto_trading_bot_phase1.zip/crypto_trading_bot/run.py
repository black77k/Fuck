"""
run.py
═══════════════════════════════════════════════════════════════════
نقطة الإقلاع الوحيدة للنظام. يجمّع: الإعدادات → الـ Logging →
بوت تليجرام. المراحل القادمة تضيف هنا: Market Data Engine
(يشتغل كـ background task)، وربطه بمحرك الإشارات.
"""

import logging

from app.core.config import settings, log_startup_banner
from app.core.logging_config import setup_logging

setup_logging()
logger = logging.getLogger("run")


def main() -> None:
    log_startup_banner()

    # فحص أمني إجباري: يمنع الإقلاع بالخطأ بوضع live بدون انتباه
    if settings.is_live():
        logger.warning(
            "🔴🔴🔴 النظام سيبدأ بوضع LIVE — تداول حقيقي بأموال حقيقية. "
            "تأكد إن هذا مقصود قبل المتابعة. 🔴🔴🔴"
        )

    from app.telegram_bot.bot import build_application

    app = build_application()
    logger.info("🚀 بوت تليجرام بدأ العمل (Polling)...")
    app.run_polling()


if __name__ == "__main__":
    main()
