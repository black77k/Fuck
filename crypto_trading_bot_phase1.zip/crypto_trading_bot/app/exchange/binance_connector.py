"""
app/exchange/binance_connector.py
═══════════════════════════════════════════════════════════════════
طبقة الاتصال الوحيدة مع Binance بكل النظام (Single Point of Contact).

لماذا ccxt ولا python-binance مباشرة؟
    ccxt مكتبة موحّدة تدعم عشرات المنصات بنفس الواجهة. اليوم نستخدم
    Binance فقط، لكن لو احتجنا لاحقًا ندعم منصة ثانية (مثلاً لمقارنة
    الأسعار أو Arbitrage)، ما نعيد كتابة طبقة الاتصال من الصفر.
    البديل المرفوض: الاتصال المباشر بـ REST API بدون مكتبة — يعني
    إعادة اختراع rate-limiting وتوقيع الطلبات ومعالجة الأخطاء يدويًا،
    وهذا خطر أمني وهندسي غير مبرر.

مبادئ أمنية صارمة مطبّقة بهذا الملف:
    1. لا يوجد أي مسار بالكود يرسل أمر تنفيذ حقيقي إلا لو
       TRADING_MODE == LIVE بشكل صريح.
    2. عند أول اتصال بـ Testnet/Live، نتحقق من صلاحيات الـ API Key
       ونرفض العمل لو صلاحية السحب (Withdraw) مفعّلة — سياسة صارمة
       غير قابلة للتجاوز، لأن تسريب مفتاح بصلاحية سحب = خسارة كاملة
       لرأس المال بغض النظر عن أي خطأ برمجي آخر.
    3. بوضع Paper، لا يوجد اتصال فعلي بأي مفتاح — كل شي محاكاة محلية.
"""

import logging
import time
from dataclasses import dataclass, field

import ccxt

from app.core.config import settings, TradingMode

logger = logging.getLogger("exchange.binance")


class WithdrawalPermissionError(RuntimeError):
    """يُرفع فورًا لو اكتشف النظام إن مفتاح API فيه صلاحية سحب."""


class LiveTradingNotEnabledError(RuntimeError):
    """يُرفع لو حاول أي جزء بالكود ينفذ أمر حقيقي والوضع مو Live."""


@dataclass
class AccountBalance:
    asset: str
    free: float
    used: float
    total: float


@dataclass
class TickerSnapshot:
    symbol: str
    last: float
    bid: float
    ask: float
    high_24h: float
    low_24h: float
    change_24h_percent: float
    volume_24h: float
    timestamp_ms: int


@dataclass
class PaperAccount:
    """محفظة وهمية محلية بالكامل — لا تلمس Binance إطلاقًا."""
    balances: dict = field(default_factory=lambda: {"USDT": settings.PAPER_STARTING_BALANCE_USDT})
    open_orders: list = field(default_factory=list)
    order_history: list = field(default_factory=list)
    _next_order_id: int = 1

    def next_order_id(self) -> str:
        oid = f"PAPER-{self._next_order_id:06d}"
        self._next_order_id += 1
        return oid


class BinanceConnector:
    """
    الواجهة الموحّدة لكل تعاملات Binance بالنظام. أي جزء ثاني بالكود
    (Market Data, Strategy, Execution...) يتعامل معها فقط — ولا يفتح
    اتصال ccxt خاص فيه أبدًا.
    """

    def __init__(self) -> None:
        self.mode: TradingMode = settings.TRADING_MODE
        self._exchange: ccxt.binance | None = None
        self._paper_account = PaperAccount() if self.mode == TradingMode.PAPER else None
        self._permissions_verified = False

        if self.mode != TradingMode.PAPER:
            self._init_real_exchange()

        logger.info("تم تهيئة BinanceConnector بوضع: %s", self.mode.value.upper())

    # ────────────────────────────────────────────────────────────
    #  التهيئة والاتصال الحقيقي (Testnet / Live فقط)
    # ────────────────────────────────────────────────────────────
    def _init_real_exchange(self) -> None:
        settings.require_binance_credentials()

        self._exchange = ccxt.binance({
            "apiKey": settings.BINANCE_API_KEY,
            "secret": settings.BINANCE_API_SECRET,
            "enableRateLimit": True,
            "options": {"defaultType": "spot"},
        })

        if self.mode == TradingMode.TESTNET:
            self._exchange.set_sandbox_mode(True)
            logger.info("تم تفعيل Binance Testnet (شبكة تجريبية).")

        self._verify_api_permissions()

    def _verify_api_permissions(self) -> None:
        """
        فحص إجباري عند الإقلاع: يمنع تشغيل النظام لو مفتاح API عنده
        صلاحية سحب. هذا الفحص لا يمكن تعطيله من الإعدادات عمدًا —
        أي محاولة لتجاوزه تعني كسر مبدأ أمني أساسي بالمشروع.
        """
        try:
            account_info = self._exchange.fetch_balance()
            permissions = account_info.get("info", {}).get("permissions", [])
        except Exception as e:
            logger.error("فشل التحقق من صلاحيات API Key: %s", e)
            raise

        if "WITHDRAW" in permissions or "WITHDRAWALS" in permissions:
            raise WithdrawalPermissionError(
                "⛔ مفتاح Binance API عنده صلاحية سحب (Withdrawal) مفعّلة. "
                "النظام يرفض العمل بهذا المفتاح لحماية رأس المال. "
                "روح لإعدادات API بـ Binance وأنشئ مفتاح جديد بدون "
                "صلاحية سحب، فعّل بس 'Enable Reading' و 'Enable Spot Trading'."
            )

        self._permissions_verified = True
        logger.info("✅ تم التحقق من صلاحيات API Key — لا توجد صلاحية سحب.")

    # ────────────────────────────────────────────────────────────
    #  قراءة البيانات (متاحة بكل الأوضاع)
    # ────────────────────────────────────────────────────────────
    def fetch_ticker(self, symbol: str) -> TickerSnapshot:
        if self.mode == TradingMode.PAPER:
            return self._paper_fetch_ticker(symbol)

        t = self._exchange.fetch_ticker(symbol)
        return TickerSnapshot(
            symbol=symbol,
            last=t["last"],
            bid=t["bid"],
            ask=t["ask"],
            high_24h=t["high"],
            low_24h=t["low"],
            change_24h_percent=t["percentage"],
            volume_24h=t["quoteVolume"],
            timestamp_ms=t["timestamp"],
        )

    def _paper_fetch_ticker(self, symbol: str) -> TickerSnapshot:
        """
        بوضع Paper، ما عندنا اتصال حقيقي بمفتاح — لكن نحتاج أسعار
        حقيقية عشان المحاكاة تكون واقعية. نستخدم اتصال Binance
        Public API (بدون مفتاح، بيانات عامة فقط — قراءة لا تتطلب
        أي صلاحية) لجلب السعر الفعلي.
        """
        public_client = ccxt.binance()  # بدون مفاتيح — endpoints عامة فقط
        t = public_client.fetch_ticker(symbol)
        return TickerSnapshot(
            symbol=symbol,
            last=t["last"],
            bid=t["bid"],
            ask=t["ask"],
            high_24h=t["high"],
            low_24h=t["low"],
            change_24h_percent=t["percentage"],
            volume_24h=t["quoteVolume"],
            timestamp_ms=t["timestamp"],
        )

    def fetch_order_book(self, symbol: str, limit: int = 20) -> dict:
        client = self._exchange if self.mode != TradingMode.PAPER else ccxt.binance()
        return client.fetch_order_book(symbol, limit=limit)

    def fetch_ohlcv(self, symbol: str, timeframe: str = "1h", limit: int = 200) -> list:
        client = self._exchange if self.mode != TradingMode.PAPER else ccxt.binance()
        return client.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)

    # ────────────────────────────────────────────────────────────
    #  الرصيد
    # ────────────────────────────────────────────────────────────
    def fetch_balances(self) -> list[AccountBalance]:
        if self.mode == TradingMode.PAPER:
            return [
                AccountBalance(asset=asset, free=amount, used=0.0, total=amount)
                for asset, amount in self._paper_account.balances.items()
            ]

        raw = self._exchange.fetch_balance()
        result = []
        for asset, total in raw.get("total", {}).items():
            if total and total > 0:
                result.append(AccountBalance(
                    asset=asset,
                    free=raw["free"].get(asset, 0.0),
                    used=raw["used"].get(asset, 0.0),
                    total=total,
                ))
        return result

    # ────────────────────────────────────────────────────────────
    #  تنفيذ الأوامر — محمي بشدة (المرحلة القادمة توسّعه بالتفصيل)
    # ────────────────────────────────────────────────────────────
    def place_market_order(self, symbol: str, side: str, amount: float) -> dict:
        """
        side: 'buy' أو 'sell'
        بوضع Paper: محاكاة فورية بسعر السوق الحالي، بدون أي اتصال تنفيذي حقيقي.
        بوضع Live: يتطلب TRADING_MODE=live صريح — وإلا يرفض فورًا.
        """
        if side not in ("buy", "sell"):
            raise ValueError("side يجب أن يكون 'buy' أو 'sell'")

        if self.mode == TradingMode.PAPER:
            return self._paper_place_market_order(symbol, side, amount)

        if not settings.is_live():
            raise LiveTradingNotEnabledError(
                "محاولة تنفيذ أمر حقيقي والنظام مو بوضع Live. "
                "هذا الحد أمني إجباري — TRADING_MODE=live مطلوب صراحة."
            )

        logger.warning("🔴 تنفيذ أمر حقيقي: %s %s %s", side.upper(), amount, symbol)
        order = self._exchange.create_market_order(symbol, side, amount)
        return order

    def _paper_place_market_order(self, symbol: str, side: str, amount: float) -> dict:
        ticker = self._paper_fetch_ticker(symbol)
        price = ticker.last
        cost = price * amount

        base, quote = symbol.split("/")

        if side == "buy":
            available_quote = self._paper_account.balances.get(quote, 0.0)
            if cost > available_quote:
                raise ValueError(
                    f"[Paper] رصيد {quote} غير كافٍ: متاح {available_quote:.2f}, مطلوب {cost:.2f}"
                )
            self._paper_account.balances[quote] = available_quote - cost
            self._paper_account.balances[base] = self._paper_account.balances.get(base, 0.0) + amount
        else:  # sell
            available_base = self._paper_account.balances.get(base, 0.0)
            if amount > available_base:
                raise ValueError(
                    f"[Paper] رصيد {base} غير كافٍ: متاح {available_base:.6f}, مطلوب {amount:.6f}"
                )
            self._paper_account.balances[base] = available_base - amount
            self._paper_account.balances[quote] = self._paper_account.balances.get(quote, 0.0) + cost

        order = {
            "id": self._paper_account.next_order_id(),
            "symbol": symbol,
            "side": side,
            "amount": amount,
            "price": price,
            "cost": cost,
            "status": "filled",
            "timestamp": int(time.time() * 1000),
            "mode": "paper",
        }
        self._paper_account.order_history.append(order)
        logger.info(
            "📝 [Paper] تنفيذ محاكاة: %s %.6f %s @ $%.2f (التكلفة: $%.2f)",
            side.upper(), amount, symbol, price, cost,
        )
        return order

    def get_order_history(self) -> list[dict]:
        if self.mode == TradingMode.PAPER:
            return list(self._paper_account.order_history)
        return self._exchange.fetch_closed_orders()


# نسخة واحدة تُستخدم بكل النظام — يتم إنشاؤها مرة عند الإقلاع
_connector_instance: BinanceConnector | None = None


def get_connector() -> BinanceConnector:
    global _connector_instance
    if _connector_instance is None:
        _connector_instance = BinanceConnector()
    return _connector_instance
