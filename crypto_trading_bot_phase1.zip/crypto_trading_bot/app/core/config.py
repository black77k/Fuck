"""
app/core/config.py
═══════════════════════════════════════════════════════════════════
طبقة الإعدادات المركزية للنظام (Core Configuration Layer).

كل إعداد بالنظام يمر من هنا — ولا يوجد أي مكان ثاني بالكود يقرأ
os.environ مباشرة لمفاتيح حساسة. هذا مبدأ أمني أساسي: نقطة واحدة
للحقيقة (Single Source of Truth) للإعدادات، وسهولة تدقيق أمني.

لماذا pydantic-settings ولا os.environ مباشرة؟
    - يتحقق من الأنواع تلقائيًا (fail-fast لو متغير غلط).
    - يمنع نسيان متغير مطلوب — النظام يرفض يشتغل لو ناقص إعداد حرج.
    - يسهل كتابة Unit Tests بدون لمس متغيرات البيئة الحقيقية.
"""

import logging
from enum import Enum
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger("core.config")


class TradingMode(str, Enum):
    """
    أوضاع التداول — من الأأمن للأخطر. النظام يبدأ دائمًا بـ PAPER
    ولا ينتقل لوضع أعلى إلا بتفعيل صريح ومقروء من المستخدم.
    """
    PAPER = "paper"        # محاكاة كاملة — بدون اتصال حقيقي بالتنفيذ
    TESTNET = "testnet"    # شبكة Binance التجريبية — حقيقية لكن بأموال وهمية
    LIVE = "live"           # تداول حقيقي بأموال حقيقية — يتطلب تأكيد صريح


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    # ── وضع التشغيل ──────────────────────────────────────────────
    TRADING_MODE: TradingMode = Field(
        default=TradingMode.PAPER,
        description="وضع التداول الحالي. يبدأ دائمًا Paper كافتراضي آمن.",
    )

    # ── بيانات اعتماد Binance (لا قيمة افتراضية — يجب توفيرها) ──
    BINANCE_API_KEY: str = Field(default="", repr=False)
    BINANCE_API_SECRET: str = Field(default="", repr=False)

    # ── تليجرام ──────────────────────────────────────────────────
    TELEGRAM_BOT_TOKEN: str = Field(default="", repr=False)
    # قائمة معرّفات تليجرام المصرّح لها تستخدم البوت (Authorization)
    # فاضية = أي حد يقدر يستخدم البوت (غير موصى به لوضع Live)
    TELEGRAM_ALLOWED_CHAT_IDS: str = Field(default="")

    # ── إدارة المخاطر — الإعدادات الحرجة (المرحلة القادمة توسّعها) ──
    MAX_RISK_PER_TRADE_PERCENT: float = Field(default=1.0, ge=0.1, le=10.0)
    MAX_DAILY_LOSS_PERCENT: float = Field(default=3.0, ge=0.5, le=20.0)
    MAX_OPEN_POSITIONS: int = Field(default=3, ge=1, le=20)

    # ── رأس المال الافتراضي لمحاكاة Paper Trading ──────────────────
    PAPER_STARTING_BALANCE_USDT: float = Field(default=10_000.0, gt=0)

    # ── عامة ─────────────────────────────────────────────────────
    LOG_LEVEL: str = Field(default="INFO")
    APP_ENV: str = Field(default="development")

    # ────────────────────────────────────────────────────────────
    #  تحققات أمنية عند الإقلاع (Fail-Fast)
    # ────────────────────────────────────────────────────────────
    @field_validator("TELEGRAM_BOT_TOKEN")
    @classmethod
    def _validate_telegram_token(cls, v: str) -> str:
        if v and ":" not in v:
            raise ValueError(
                "TELEGRAM_BOT_TOKEN لا يبدو صحيحًا (يجب أن يحتوي على ':'). "
                "تأكد إنك ما لصقت حرف زائد بالخطأ."
            )
        return v.strip()

    def allowed_chat_ids(self) -> set[int]:
        """يحوّل النص 'id1,id2,id3' إلى مجموعة أرقام صحيحة."""
        raw = self.TELEGRAM_ALLOWED_CHAT_IDS.strip()
        if not raw:
            return set()
        return {int(x.strip()) for x in raw.split(",") if x.strip()}

    def require_binance_credentials(self) -> None:
        """يستدعى فقط عند الحاجة الفعلية لاتصال حقيقي (Testnet/Live)."""
        if not self.BINANCE_API_KEY or not self.BINANCE_API_SECRET:
            raise RuntimeError(
                "وضع التشغيل الحالي يتطلب BINANCE_API_KEY و BINANCE_API_SECRET. "
                "بوضع Paper Trading ما تحتاجهم إطلاقًا."
            )

    def is_live(self) -> bool:
        return self.TRADING_MODE == TradingMode.LIVE


# نسخة واحدة (Singleton) تُستخدم بكل النظام — يتم تحميلها مرة واحدة عند الإقلاع
settings = Settings()


def log_startup_banner() -> None:
    """يطبع ملخص إعدادات آمن (بدون أي سر) عند إقلاع النظام."""
    mode_warning = ""
    if settings.TRADING_MODE == TradingMode.LIVE:
        mode_warning = "  ⚠️⚠️⚠️  تحذير: النظام بوضع LIVE — تداول حقيقي بأموال حقيقية!  ⚠️⚠️⚠️"

    logger.info("═" * 60)
    logger.info("  نظام التداول الآلي — بدء التشغيل")
    logger.info("  وضع التداول    : %s", settings.TRADING_MODE.value.upper())
    logger.info("  بيئة التشغيل   : %s", settings.APP_ENV)
    logger.info("  حد المخاطرة    : %.1f%% لكل صفقة", settings.MAX_RISK_PER_TRADE_PERCENT)
    logger.info("  حد الخسارة اليومي: %.1f%%", settings.MAX_DAILY_LOSS_PERCENT)
    if mode_warning:
        logger.warning(mode_warning)
    logger.info("═" * 60)
