"""
app/core/logging_config.py
═══════════════════════════════════════════════════════════════════
Logging احترافي مع حماية إجبارية ضد تسريب الأسرار.

لماذا فلتر مخصص ولا نعتمد على "الانتباه" فقط؟
    لأن الانتباه البشري يفشل عاجلاً أو آجلاً. أي Exception يطبع
    Traceback ممكن يظهر فيه متغير API_SECRET بالغلط لو ظهر بأي
    مكان بالـ call stack. الفلتر هنا يفحص كل رسالة قبل ما تُطبع
    ويستبدل أي نص يشبه سر معروف بـ ***REDACTED***.
"""

import logging
import re
import sys

from app.core.config import settings

_SECRET_PATTERNS: list[re.Pattern] = []


def _register_secret(value: str) -> None:
    """يسجل قيمة سرية عشان الفلتر يخفيها من كل سجل يطبع لاحقًا."""
    if value and len(value) >= 6:
        _SECRET_PATTERNS.append(re.compile(re.escape(value)))


class RedactSecretsFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True
        redacted = msg
        for pattern in _SECRET_PATTERNS:
            redacted = pattern.sub("***REDACTED***", redacted)
        if redacted != msg:
            record.msg = redacted
            record.args = ()
        return True


def setup_logging() -> None:
    # سجّل الأسرار الحالية عشان الفلتر يقدر يخفيها
    _register_secret(settings.BINANCE_API_KEY)
    _register_secret(settings.BINANCE_API_SECRET)
    _register_secret(settings.TELEGRAM_BOT_TOKEN)

    root = logging.getLogger()
    root.setLevel(settings.LOG_LEVEL)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s │ %(levelname)-8s │ %(name)-25s │ %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    handler.addFilter(RedactSecretsFilter())

    root.handlers.clear()
    root.addHandler(handler)

    # مكتبات خارجية مزعجة بالـ DEBUG — نخليها أهدأ
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)
    logging.getLogger("ccxt").setLevel(logging.WARNING)
