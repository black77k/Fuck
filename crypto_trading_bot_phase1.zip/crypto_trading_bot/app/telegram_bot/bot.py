"""
app/telegram_bot/bot.py
═══════════════════════════════════════════════════════════════════
واجهة تليجرام — نقطة التحكم الوحيدة بالنظام حسب طلبك.

المرحلة الحالية (Phase 1) توفر بس:
    /start    — ترحيب + عرض وضع التشغيل الحالي
    /status   — حالة النظام (وضع التداول، حالة الاتصال بـ Binance)
    /balance  — الرصيد الحالي (حقيقي أو محاكى حسب الوضع)
    /price    — سعر أي زوج تداول لحظي (مثال: /price BTC/USDT)
    /mode     — عرض وضع التداول الحالي بوضوح

المراحل القادمة (2 وما بعدها) بتضيف:
    Market Data Engine + المؤشرات + Signal Engine + Risk Engine +
    أوامر BUY/SELL/HOLD بثقة (Confidence Score) + إدارة الصفقات...

نظام التفويض (Authorization):
    لو TELEGRAM_ALLOWED_CHAT_IDS محدد بالإعدادات، البوت يرفض أي
    شخص مو موجود بالقائمة — هذا حرج جدًا وقت الانتقال لوضع Live،
    لأن أي شخص يقدر يتكلم مع البوت بدون هذا الفحص = يقدر يتحكم
    بصفقاتك.
"""

import logging

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

from app.core.config import settings, TradingMode
from app.exchange.binance_connector import get_connector, WithdrawalPermissionError

logger = logging.getLogger("telegram_bot")


# ══════════════════════════════════════════════════════════════════
#  حماية التفويض — Decorator يُطبّق على كل أمر حساس
# ══════════════════════════════════════════════════════════════════
def authorized_only(handler):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        allowed = settings.allowed_chat_ids()
        chat_id = update.effective_chat.id

        if allowed and chat_id not in allowed:
            logger.warning("🚫 محاولة وصول غير مصرح بها من chat_id=%s", chat_id)
            await update.message.reply_text(
                "⛔ ما عندك صلاحية استخدام هذا البوت. تواصل مع المسؤول."
            )
            return
        return await handler(update, context)

    return wrapper


# ══════════════════════════════════════════════════════════════════
#  الأوامر
# ══════════════════════════════════════════════════════════════════
@authorized_only
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    mode_labels = {
        TradingMode.PAPER: "📝 محاكاة (Paper Trading) — بدون مال حقيقي",
        TradingMode.TESTNET: "🧪 شبكة تجريبية (Testnet)",
        TradingMode.LIVE: "🔴 تداول حقيقي (LIVE)",
    }
    text = (
        "🤖 *نظام التداول الآلي — المرحلة 1: الأساس*\n\n"
        f"وضع التشغيل الحالي: {mode_labels[settings.TRADING_MODE]}\n\n"
        "الأوامر المتاحة حاليًا:\n"
        "/status — حالة النظام\n"
        "/balance — الرصيد الحالي\n"
        "/price BTC/USDT — سعر لحظي لأي زوج\n"
        "/mode — تفاصيل وضع التداول\n\n"
        "⚠️ هذه مرحلة تأسيسية: قراءة بيانات ومحاكاة فقط. "
        "محرك الإشارات وإدارة المخاطر والتنفيذ التلقائي قادمين بالمراحل القادمة."
    )
    await update.message.reply_text(text, parse_mode="Markdown")


@authorized_only
async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        connector = get_connector()
        connection_ok = True
        error_msg = ""
    except WithdrawalPermissionError as e:
        connection_ok = False
        error_msg = str(e)
    except Exception as e:
        connection_ok = False
        error_msg = f"خطأ اتصال: {e}"

    status_icon = "🟢" if connection_ok else "🔴"
    text = (
        f"{status_icon} *حالة النظام*\n\n"
        f"وضع التداول: `{settings.TRADING_MODE.value}`\n"
        f"الاتصال بـ Binance: {'سليم ✅' if connection_ok else 'فشل ❌'}\n"
    )
    if not connection_ok:
        text += f"\n⚠️ {error_msg}"

    await update.message.reply_text(text, parse_mode="Markdown")


@authorized_only
async def balance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        connector = get_connector()
        balances = connector.fetch_balances()
    except Exception as e:
        await update.message.reply_text(f"⚠️ خطأ أثناء جلب الرصيد: {e}")
        return

    if not balances:
        await update.message.reply_text("لا يوجد رصيد حاليًا.")
        return

    mode_note = " (محاكاة 📝)" if settings.TRADING_MODE == TradingMode.PAPER else ""
    lines = [f"  • {b.asset}: {b.total:,.6f} (متاح: {b.free:,.6f})" for b in balances]
    text = f"💰 *الرصيد{mode_note}*\n\n" + "\n".join(lines)
    await update.message.reply_text(text, parse_mode="Markdown")


@authorized_only
async def price_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(
            "الاستخدام: `/price BTC/USDT`", parse_mode="Markdown"
        )
        return

    symbol = context.args[0].upper()
    try:
        connector = get_connector()
        t = connector.fetch_ticker(symbol)
    except Exception as e:
        await update.message.reply_text(f"⚠️ خطأ أثناء جلب السعر: {e}")
        return

    arrow = "🔺" if t.change_24h_percent >= 0 else "🔻"
    text = (
        f"💱 *{t.symbol}*\n"
        f"السعر: ${t.last:,.4f}\n"
        f"{arrow} 24س: {t.change_24h_percent:+.2f}%\n"
        f"Bid/Ask: ${t.bid:,.4f} / ${t.ask:,.4f}\n"
        f"أعلى/أدنى 24س: ${t.high_24h:,.4f} / ${t.low_24h:,.4f}"
    )
    await update.message.reply_text(text, parse_mode="Markdown")


@authorized_only
async def mode_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        f"⚙️ وضع التداول الحالي: `{settings.TRADING_MODE.value.upper()}`\n\n"
        "لتغيير الوضع، عدّل متغير TRADING_MODE بإعدادات السيرفر "
        "(.env أو Variables بـ Railway) وأعد تشغيل البوت.\n\n"
        "⚠️ الانتقال لوضع `live` يعني تداول حقيقي بأموال حقيقية — "
        "تأكد 100% قبل أي تغيير."
    )
    await update.message.reply_text(text, parse_mode="Markdown")


# ══════════════════════════════════════════════════════════════════
#  بناء التطبيق
# ══════════════════════════════════════════════════════════════════
def build_application() -> Application:
    if not settings.TELEGRAM_BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN غير مضبوط بالإعدادات.")

    app = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("status", status_command))
    app.add_handler(CommandHandler("balance", balance_command))
    app.add_handler(CommandHandler("price", price_command))
    app.add_handler(CommandHandler("mode", mode_command))

    return app
