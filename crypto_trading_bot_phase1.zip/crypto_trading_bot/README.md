# نظام التداول الآلي — Crypto Trading Bot

## 📍 المرحلة الحالية: Phase 1 — الأساس (Foundation)

هذي أول مرحلة من نظام تداول احترافي متعدد المراحل. تحتوي فقط على
الأساس الآمن اللي كل شي بعده يُبنى فوقه — بدون أي إشارات تداول أو
تنفيذ تلقائي حتى الآن.

### ما يعمل الآن فعليًا:
- ✅ بنية مشروع Modular قابلة للتوسع
- ✅ إعدادات مركزية آمنة (Pydantic Settings) مع فحوصات Fail-Fast
- ✅ Logging احترافي يخفي أي سر (API Key/Secret/Token) تلقائيًا من السجلات
- ✅ موصل Binance موحّد (`BinanceConnector`) يدعم 3 أوضاع:
  - **Paper** (افتراضي): محاكاة كاملة محليًا، بيانات سعر حقيقية، صفر اتصال بمفتاحك
  - **Testnet**: شبكة Binance التجريبية الحقيقية
  - **Live**: تداول حقيقي — محمي بفحص صريح إجباري
- ✅ فحص إجباري عند الإقلاع: يرفض العمل لو مفتاح API عنده صلاحية سحب (Withdrawal)
- ✅ بوت تليجرام بأوامر: `/start` `/status` `/balance` `/price` `/mode`
- ✅ نظام تفويض (Authorization) عبر `TELEGRAM_ALLOWED_CHAT_IDS`

### ما لا يوجد بعد (قادم بالمراحل التالية):
- ❌ محرك بيانات السوق اللحظي (WebSocket)
- ❌ المؤشرات الفنية (RSI, MACD, EMA...)
- ❌ محرك الإشارات (Signal Engine) وحساب الثقة (Confidence Score)
- ❌ إدارة المخاطر الكاملة (Position Sizing, Stop Loss, Drawdown Limits)
- ❌ الباك-تيست والاستراتيجيات
- ❌ التنفيذ التلقائي (Auto Trading)

---

## 🚀 التشغيل محليًا

```bash
pip install -r requirements.txt
cp .env.example .env
# افتح .env واملأ TELEGRAM_BOT_TOKEN على الأقل
python run.py
```

بوضع Paper (الافتراضي) ما تحتاج مفاتيح Binance إطلاقًا — البوت
يجلب أسعار حقيقية من Binance العامة (بدون مفتاح) ويحاكي رصيدك محليًا.

## 🧪 الانتقال لـ Testnet

```env
TRADING_MODE=testnet
BINANCE_API_KEY=مفتاحك_من_testnet.binance.vision
BINANCE_API_SECRET=سرك
```

## ⚠️ الانتقال لـ Live (تداول حقيقي)

لا تفعّله قبل ما تكتمل المراحل: Risk Engine + Backtesting +
Paper Trading Validation. لما يجي وقته:

```env
TRADING_MODE=live
BINANCE_API_KEY=مفتاح_حقيقي_بدون_صلاحية_سحب
BINANCE_API_SECRET=سر_حقيقي
TELEGRAM_ALLOWED_CHAT_IDS=رقمك_فقط
```

---

## 🗺️ خارطة الطريق الكاملة

| المرحلة | المحتوى |
|---|---|
| **1 ✅** | الأساس: Config, Logging, Binance Connector, Telegram Bot |
| 2 | Market Data Engine (WebSocket) + Coin Scanner |
| 3 | Indicators Engine (RSI, MACD, EMA, Bollinger...) |
| 4 | Order Book Analyzer + Volume Analysis |
| 5 | Market Regime Engine (Bull/Bear/Sideways) |
| 6 | Confluence & Signal Engine (Confidence Score) |
| 7 | Risk Management Engine (الأهم — Position Sizing, Kill Switch) |
| 8 | Strategy Engine (Trend Following, Breakout, Mean Reversion...) |
| 9 | Backtesting Engine + Walk Forward Testing |
| 10 | Execution Engine (Order State Machine, Idempotency) |
| 11 | Candlestick Pattern Engine |
| 12 | ML Layer (اختياري — عامل مساعد وليس قرار مستقل) |
| 13 | Database (PostgreSQL) + سجل كامل |
| 14 | Notifications + Dashboard داخل تليجرام |
| 15 | Docker + Deployment + Security Hardening النهائي |

كل مرحلة تُبنى فوق سابقتها بدون كسرها — بالضبط زي ما طلبت.

---

## 📁 بنية المشروع

```
crypto_trading_bot/
├── app/
│   ├── core/
│   │   ├── config.py           # الإعدادات المركزية
│   │   └── logging_config.py   # Logging آمن
│   ├── exchange/
│   │   └── binance_connector.py # الاتصال الوحيد بـ Binance
│   └── telegram_bot/
│       └── bot.py               # واجهة التحكم
├── tests/
├── run.py                       # نقطة الإقلاع
├── requirements.txt
├── .env.example
└── README.md
```

## ⚠️ تنويه مهم

هذا النظام أداة تحليل ومحاكاة/تنفيذ آلي — وليس نصيحة استثمارية.
أي قرار تداول حقيقي لاحقًا (بعد اكتمال المراحل) مسؤوليتك الكاملة.
لا يوجد نظام يضمن الربح 100%.
